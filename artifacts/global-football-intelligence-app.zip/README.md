# Global Football Intelligence

Plataforma de previsão de futebol com **FastAPI**, **Dixon-Coles**, **LangGraph**, **XGBoost** e frontend **React**.

Versão 0.3 — API completa + dashboard React (Vite + TypeScript).

---

## Arranque rápido

### 1. Backend

```bash
cd football_ai_app
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -e '.[dev]'

# (Opcional) dados de demo
python scripts/seed_demo.py

# API
uvicorn football_ai.main:app --reload --port 8000
```

API + Swagger: http://localhost:8000/docs

### 2. Frontend React

```bash
cd frontend
npm install
npm run dev
```

Dashboard: http://localhost:3000

O Vite faz proxy de `/api` e `/health` para `localhost:8000`.

### Docker (só API + Postgres)

```bash
cp .env.example .env
docker compose up --build
```

Depois corre o frontend localmente apontando para a API.

---

## Funcionalidades do frontend

| Página | Descrição |
|--------|-----------|
| **Dashboard** | Jogos e últimas previsões |
| **Novo Jogo** | Criar fixture + gerar previsão com sliders de xG/ρ |
| **Previsão Rápida** | Exploração interativa sem gravar (matriz + gráfico top scores) |
| **Histórico** | Previsões anteriores por jogo |
| **Sobre** | Stack e limitações |

---

## Exemplos de API

```bash
# Criar jogo
curl -X POST http://localhost:8000/api/v1/fixtures \
  -H 'Content-Type: application/json' \
  -d '{"id":"demo-001","competition":"Demo League","season":"2025/26","home_team":"Home FC","away_team":"Away FC"}'

# Previsão
curl -X POST http://localhost:8000/api/v1/fixtures/demo-001/predict \
  -H 'Content-Type: application/json' \
  -d '{"home_xg":1.55,"away_xg":1.05,"rho":-0.13}'

# Previsão rápida
curl -X POST http://localhost:8000/api/v1/predict/quick \
  -H 'Content-Type: application/json' \
  -d '{"home_xg":1.8,"away_xg":1.2}'
```

---

## Arquitetura

```
football_ai_app/
├── src/football_ai/          # Backend FastAPI
│   ├── main.py
│   ├── prediction/dixon_coles.py
│   └── agents/graph.py
├── frontend/                 # React + Vite + TypeScript
│   ├── src/
│   │   ├── pages/            # Dashboard, Novo, Previsão, Histórico
│   │   ├── components/       # ProbMetrics, ScoreMatrix, Chart
│   │   └── api/client.ts
│   └── package.json
├── streamlit_app.py          # Dashboard alternativo (opcional)
└── scripts/seed_demo.py
```

---

## Testes backend

```bash
pytest -q
```

## Build de produção do frontend

```bash
cd frontend
npm run build
# ficheiros em frontend/dist — servir com nginx ou montar no FastAPI
```

---

## Limitações

- xG manuais (sem estimador treinado integrado)
- Dixon-Coles sem ajuste de forças a partir de histórico
- Sem odds em tempo real / lesões / lineups
