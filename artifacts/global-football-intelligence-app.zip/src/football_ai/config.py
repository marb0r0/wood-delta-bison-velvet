from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str = "sqlite:///./football_ai.db"
    app_env: str = "development"
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000,http://localhost:8501,http://127.0.0.1:8501"
    model_version: str = "dixon-coles-baseline-v0.2"
    default_rho: float = -0.13

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
