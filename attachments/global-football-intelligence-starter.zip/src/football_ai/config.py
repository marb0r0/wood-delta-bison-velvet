from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite:///./football_ai.db"
    app_env: str = "development"
    cors_origins: str = "http://localhost:3000"
    model_version: str = "dixon-coles-baseline-v0.1"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
