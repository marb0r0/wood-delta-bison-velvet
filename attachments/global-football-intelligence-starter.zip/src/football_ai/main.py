from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session
from football_ai.db import get_db
from football_ai.models import Fixture, Prediction
from football_ai.schemas import FixtureCreate, FixtureOut
from football_ai.prediction.dixon_coles import score_matrix, summarize
from football_ai.agents.graph import build_graph
from football_ai.config import settings

app = FastAPI(title="Global Football Intelligence API", version="0.1.0")
workflow = build_graph()

@app.get("/health")
def health():
    return {"status": "ok", "environment": settings.app_env}

@app.post("/api/v1/fixtures", response_model=FixtureOut)
def create_fixture(payload: FixtureCreate, db: Session = Depends(get_db)):
    if db.get(Fixture, payload.id):
        raise HTTPException(status_code=409, detail="fixture already exists")
    fixture = Fixture(**payload.model_dump())
    db.add(fixture)
    db.commit()
    db.refresh(fixture)
    return fixture

@app.get("/api/v1/fixtures")
def list_fixtures(db: Session = Depends(get_db)):
    return db.query(Fixture).order_by(Fixture.kickoff_utc.desc()).limit(100).all()

@app.post("/api/v1/fixtures/{fixture_id}/predict")
def predict_fixture(fixture_id: str, home_xg: float = 1.45, away_xg: float = 1.10,
                    db: Session = Depends(get_db)):
    fixture = db.get(Fixture, fixture_id)
    if not fixture:
        raise HTTPException(status_code=404, detail="fixture not found")
    result = workflow.invoke({
        "fixture_id": fixture_id, "home_xg": home_xg, "away_xg": away_xg
    })
    if result.get("quality_status") != "ok":
        raise HTTPException(status_code=422, detail="invalid expected goals")
    probs = result["probabilities"]
    record = Prediction(
        fixture_id=fixture_id, model_version=settings.model_version,
        home_xg=home_xg, away_xg=away_xg,
        home_win=probs["home_win"], draw=probs["draw"], away_win=probs["away_win"],
        over_2_5=probs["over_2_5"], btts_yes=probs["btts_yes"],
    )
    db.add(record)
    db.commit()
    return {
        "fixture_id": fixture_id, "model_version": settings.model_version,
        "home_xg": home_xg, "away_xg": away_xg, **probs,
        "score_matrix": result["matrix"],
    }

@app.get("/api/v1/fixtures/{fixture_id}/predictions")
def prediction_history(fixture_id: str, db: Session = Depends(get_db)):
    return db.query(Prediction).filter(Prediction.fixture_id == fixture_id).order_by(
        Prediction.predicted_at.desc()
    ).all()
