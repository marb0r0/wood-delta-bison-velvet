"""Transparent independent-Poisson baseline with Dixon-Coles low-score adjustment.

This is an inference baseline, not a fitted league model. Production use should fit
attack/defence strengths and rho on historical, time-ordered competition data.
"""
from math import exp, factorial

def _poisson_pmf(k: int, lam: float) -> float:
    return exp(-lam) * lam**k / factorial(k)

def score_matrix(home_xg: float, away_xg: float, max_goals: int = 10,
                 rho: float = 0.0) -> list[list[float]]:
    if home_xg <= 0 or away_xg <= 0:
        raise ValueError("expected goals must be positive")
    matrix = []
    for h in range(max_goals + 1):
        row = []
        for a in range(max_goals + 1):
            p = _poisson_pmf(h, home_xg) * _poisson_pmf(a, away_xg)
            # Dixon-Coles tau correction for the four low-score outcomes.
            if (h, a) == (0, 0):
                tau = 1 - home_xg * away_xg * rho
            elif (h, a) == (0, 1):
                tau = 1 + home_xg * rho
            elif (h, a) == (1, 0):
                tau = 1 + away_xg * rho
            elif (h, a) == (1, 1):
                tau = 1 - rho
            else:
                tau = 1.0
            row.append(max(0.0, p * tau))
        matrix.append(row)
    total = sum(map(sum, matrix))
    return [[v / total for v in row] for row in matrix]

def summarize(matrix: list[list[float]]) -> dict:
    n = len(matrix)
    home = sum(matrix[h][a] for h in range(n) for a in range(n) if h > a)
    draw = sum(matrix[h][a] for h in range(n) for a in range(n) if h == a)
    away = sum(matrix[h][a] for h in range(n) for a in range(n) if h < a)
    over25 = sum(matrix[h][a] for h in range(n) for a in range(n) if h + a >= 3)
    btts = sum(matrix[h][a] for h in range(1, n) for a in range(1, n))
    return {"home_win": home, "draw": draw, "away_win": away,
            "over_2_5": over25, "btts_yes": btts}
