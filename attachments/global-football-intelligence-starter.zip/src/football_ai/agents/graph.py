"""Small LangGraph workflow. The deterministic prediction engine remains authoritative."""
from typing import TypedDict
from langgraph.graph import StateGraph, END
from football_ai.prediction.dixon_coles import score_matrix, summarize

class MatchState(TypedDict, total=False):
    fixture_id: str
    home_xg: float
    away_xg: float
    matrix: list[list[float]]
    probabilities: dict
    quality_status: str

def validate(state: MatchState) -> MatchState:
    if state.get("home_xg", 0) <= 0 or state.get("away_xg", 0) <= 0:
        return {"quality_status": "rejected"}
    return {"quality_status": "ok"}

def predict(state: MatchState) -> MatchState:
    matrix = score_matrix(state["home_xg"], state["away_xg"])
    return {"matrix": matrix, "probabilities": summarize(matrix)}

def build_graph():
    graph = StateGraph(MatchState)
    graph.add_node("validate", validate)
    graph.add_node("predict", predict)
    graph.set_entry_point("validate")
    graph.add_conditional_edges(
        "validate",
        lambda s: "predict" if s["quality_status"] == "ok" else END,
        {"predict": "predict", END: END},
    )
    graph.add_edge("predict", END)
    return graph.compile()
