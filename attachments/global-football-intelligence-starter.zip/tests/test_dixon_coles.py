import pytest
from football_ai.prediction.dixon_coles import score_matrix, summarize

def test_probabilities_sum_to_one():
    matrix = score_matrix(1.4, 1.1)
    assert sum(map(sum, matrix)) == pytest.approx(1.0)

def test_1x2_probabilities_sum_to_one():
    probs = summarize(score_matrix(1.5, 0.9))
    assert probs["home_win"] + probs["draw"] + probs["away_win"] == pytest.approx(1.0)

def test_invalid_xg_rejected():
    with pytest.raises(ValueError):
        score_matrix(0, 1.0)
