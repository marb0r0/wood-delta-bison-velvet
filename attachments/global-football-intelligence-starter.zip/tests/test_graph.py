from football_ai.agents.graph import build_graph

def test_langgraph_prediction_flow():
    result = build_graph().invoke({"fixture_id": "x", "home_xg": 1.4, "away_xg": 1.0})
    assert result["quality_status"] == "ok"
    assert "home_win" in result["probabilities"]

def test_langgraph_rejects_invalid_input():
    result = build_graph().invoke({"fixture_id": "x", "home_xg": 0, "away_xg": 1.0})
    assert result["quality_status"] == "rejected"
