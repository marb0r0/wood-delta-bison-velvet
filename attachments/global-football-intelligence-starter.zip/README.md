# Global Football Intelligence — starter

Executável local para desenvolver uma plataforma de previsão de futebol com FastAPI,
PostgreSQL, LangGraph, Dixon-Coles e XGBoost. O projeto é intencionalmente um **starter**:
não contém previsões globais prontas nem dados licenciados.

## Requisitos
- Docker Desktop / Docker Engine + Compose
- Git
- (Opcional, execução local) Python 3.11+

## Arranque com Docker
```bash
cp .env.example .env
docker compose up --build
```
A API fica em http://localhost:8000 e Swagger em http://localhost:8000/docs.
A migração Alembic é executada no arranque do container API.

## Exemplo de utilização
Criar um jogo:
```bash
curl -X POST http://localhost:8000/api/v1/fixtures \
  -H 'Content-Type: application/json' \
  -d '{
    "id":"demo-001",
    "competition":"Demo League",
    "season":"2025/26",
    "home_team":"Home FC",
    "away_team":"Away FC"
  }'
```
Gerar uma previsão baseline:
```bash
curl -X POST 'http://localhost:8000/api/v1/fixtures/demo-001/predict?home_xg=1.55&away_xg=1.05'
```
Os xG são fornecidos manualmente nesta primeira versão. Ainda não existe um estimador treinado de xG integrado.

## Testes locais
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -e '.[dev]'
pytest
```

## Treinar XGBoost
Preparar CSV cronológico com colunas:
`kickoff_utc,home_elo_diff,home_form_points,away_form_points,home_xg_for,home_xg_against,away_xg_for,away_xg_against,result`
onde `result` é H, D ou A.
```bash
python -c "from football_ai.prediction.xgb_model import train; train('data/processed/matches.csv')"
```
O modelo XGBoost é um módulo de treino separado; a API ainda usa Dixon-Coles baseline.
Não promover o modelo sem validação walk-forward, calibração e comparação com baselines.

## Dados abertos
- StatsBomb Open Data: https://github.com/statsbomb/open-data
- Verifique a licença e as condições de cada dataset antes de usar.
O importador incluído é um exemplo para JSON de jogos; não importa eventos nem resultados automaticamente.
Para cobertura global real será necessário integrar fornecedores por adaptadores e documentar cobertura por liga/época.

## Limitações conhecidas
- Dixon-Coles implementado aqui aplica correção de baixa pontuação, mas usa xG de entrada; não estima parâmetros ataque/defesa a partir de histórico.
- Mercados de cantos, cartões e jogador ainda não estão implementados.
- O workflow LangGraph demonstra validação e previsão, sem agentes LLM externos.
- Sem odds em tempo real, lesões globais ou lineups.
- A matriz de golos é truncada em 10 e renormalizada.
- Passwords do Compose são apenas para desenvolvimento local. Nunca reutilizar em produção.

## Próximos passos
1. Importar resultados históricos com proveniência e timestamps.
2. Implementar estimador Dixon-Coles por competição/época.
3. Construir features point-in-time e validação walk-forward.
4. Ligar XGBoost ao serviço de inferência após avaliação.
5. Criar modelos específicos para cantos, cartões e props de jogadores.
6. Acrescentar dashboard e monitorização.
